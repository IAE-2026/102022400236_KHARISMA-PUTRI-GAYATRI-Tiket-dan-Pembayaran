<?php declare(strict_types=1);

namespace Nuwave\Lighthouse;

use GraphQL\Error\DebugFlag;
use GraphQL\Error\Error;
use GraphQL\Error\SyntaxError;
use GraphQL\Executor\ExecutionResult;
use GraphQL\GraphQL as GraphQLBase;
use GraphQL\Language\AST\DocumentNode;
use GraphQL\Language\Parser;
use GraphQL\Server\Helper as GraphQLHelper;
use GraphQL\Server\OperationParams;
use GraphQL\Server\RequestError;
use GraphQL\Type\Schema;
use GraphQL\Validator\DocumentValidator;
use GraphQL\Validator\Rules\QueryComplexity;
use Illuminate\Container\Container;
use Illuminate\Contracts\Cache\Factory as CacheFactory;
use Illuminate\Contracts\Config\Repository as ConfigRepository;
use Illuminate\Contracts\Events\Dispatcher as EventsDispatcher;
use Illuminate\Pipeline\Pipeline;
use Illuminate\Support\Collection;
use Nuwave\Lighthouse\Cache\QueryCache;
use Nuwave\Lighthouse\Events\BuildExtensionsResponse;
use Nuwave\Lighthouse\Events\EndExecution;
use Nuwave\Lighthouse\Events\EndOperationOrOperations;
use Nuwave\Lighthouse\Events\ManipulateResult;
use Nuwave\Lighthouse\Events\StartExecution;
use Nuwave\Lighthouse\Events\StartOperationOrOperations;
use Nuwave\Lighthouse\Execution\BatchLoader\BatchLoaderRegistry;
use Nuwave\Lighthouse\Execution\CacheableValidationRulesProvider;
use Nuwave\Lighthouse\Execution\ErrorPool;
use Nuwave\Lighthouse\Schema\SchemaBuilder;
use Nuwave\Lighthouse\Schema\Values\FieldValue;
use Nuwave\Lighthouse\Support\Contracts\GraphQLContext;
use Nuwave\Lighthouse\Support\Contracts\ProvidesValidationRules;
use Nuwave\Lighthouse\Support\Utils as LighthouseUtils;

/**
 * The main entrypoint to GraphQL execution.
 *
 * @api
 *
 * @phpstan-import-type ErrorsHandler from \GraphQL\Executor\ExecutionResult
 * @phpstan-import-type SerializableResult from \GraphQL\Executor\ExecutionResult
 */
class GraphQL
{
    /**
     * Lazily initialized.
     *
     * @var ErrorsHandler
     */
    protected $errorsHandler;

    public function __construct(
        protected SchemaBuilder $schemaBuilder,
        protected Pipeline $pipeline,
        protected EventsDispatcher $eventDispatcher,
        protected ErrorPool $errorPool,
        protected ProvidesValidationRules $providesValidationRules,
        protected GraphQLHelper $graphQLHelper,
        protected ConfigRepository $configRepository,
        protected QueryCache $queryCache,
    ) {}

    /**
     * Parses query and executes it.
     *
     * @api
     *
     * @param  array<string, mixed>|null  $variables
     *
     * @return array<string, mixed>
     */
    public function executeQueryString(
        string $query,
        GraphQLContext $context,
        ?array $variables = [],
        mixed $root = null,
        ?string $operationName = null,
    ): array {
        $queryHash = hash('sha256', $query);

        try {
            $parsedQuery = $this->parse($query, $queryHash);
        } catch (SyntaxError $syntaxError) {
            return $this->toSerializableArray(
                new ExecutionResult(null, [$syntaxError]),
            );
        }

        return $this->executeParsedQuery($parsedQuery, $context, $variables, $root, $operationName, $queryHash);
    }

    /**
     * Execute a GraphQL query on the Lighthouse schema and return the serializable result.
     *
     * @api
     *
     * @param  array<string, mixed>|null  $variables
     *
     * @return array<string, mixed>
     */
    public function executeParsedQuery(
        DocumentNode $query,
        GraphQLContext $context,
        ?array $variables = [],
        mixed $root = null,
        ?string $operationName = null,
        ?string $queryHash = null,
    ): array {
        $result = $this->executeParsedQueryRaw($query, $context, $variables, $root, $operationName, $queryHash);

        return $this->toSerializableArray($result);
    }

    /**
     * Execute a GraphQL query on the Lighthouse schema and return the raw result.
     *
     * @param  array<string, mixed>|null  $variables
     */
    public function executeParsedQueryRaw(
        DocumentNode $query,
        GraphQLContext $context,
        ?array $variables = [],
        mixed $root = null,
        ?string $operationName = null,
        ?string $queryHash = null,
    ): ExecutionResult {
        // Building the executable schema might take a while to do,
        // so we do it before we fire the StartExecution event.
        // This allows tracking the time for batched queries independently.
        $schema = $this->schemaBuilder->schema();

        $this->eventDispatcher->dispatch(
            new StartExecution($schema, $query, $variables, $operationName, $context),
        );

        if ($this->providesValidationRules instanceof CacheableValidationRulesProvider) {
            $cacheableValidationRules = $this->providesValidationRules->cacheableValidationRules();

            $errors = $this->validateCacheableRules($cacheableValidationRules, $schema, $this->schemaBuilder->schemaHash(), $query, $queryHash);
            if ($errors !== []) {
                return new ExecutionResult(null, $errors);
            }
        }

        $validationRules = $this->providesValidationRules->validationRules();

        $result = GraphQLBase::executeQuery(
            $schema,
            $query,
            $root,
            $context,
            $variables,
            $operationName,
            null,
            $validationRules,
        );

        $queryComplexityRule = $validationRules[QueryComplexity::class] ?? null;
        $queryComplexity = $queryComplexityRule instanceof QueryComplexity
            // TODO remove this check when updating the required version of webonyx/graphql-php
            && method_exists($queryComplexityRule, 'getQueryComplexity') // @phpstan-ignore function.alreadyNarrowedType (depends on the used library version)
                ? $queryComplexityRule->getQueryComplexity()
                : null;

        /** @var array<\Nuwave\Lighthouse\Execution\ExtensionsResponse|null> $extensionsResponses */
        $extensionsResponses = (array) $this->eventDispatcher->dispatch(
            new BuildExtensionsResponse($result, $queryComplexity),
        );

        foreach ($extensionsResponses as $extensionsResponse) {
            if ($extensionsResponse !== null) {
                $result->extensions[$extensionsResponse->key] = $extensionsResponse->content;
            }
        }

        foreach ($this->errorPool->errors() as $error) {
            $result->errors[] = $error;
        }

        // Allow listeners to manipulate the result after each resolved query
        $this->eventDispatcher->dispatch(
            new ManipulateResult($result),
        );

        $this->eventDispatcher->dispatch(
            new EndExecution($result),
        );

        $this->cleanUpAfterExecution();

        return $result;
    }

    /**
     * Run one or more GraphQL operations against the schema.
     *
     * @api
     *
     * @param  \GraphQL\Server\OperationParams|array<int, \GraphQL\Server\OperationParams>  $operationOrOperations
     *
     * @return array<string, mixed>|array<int, array<string, mixed>>
     */
    public function executeOperationOrOperations(OperationParams|array $operationOrOperations, GraphQLContext $context): array
    {
        $this->eventDispatcher->dispatch(
            new StartOperationOrOperations($operationOrOperations),
        );

        $resultOrResults = LighthouseUtils::mapEach(
            /** @return array<string, mixed> */
            fn (OperationParams $operationParams): array => $this->executeOperation($operationParams, $context),
            $operationOrOperations,
        );

        $this->eventDispatcher->dispatch(
            new EndOperationOrOperations($resultOrResults),
        );

        return $resultOrResults;
    }

    /**
     * Run a single GraphQL operation against the schema and get a result.
     *
     * @api
     *
     * @return array<string, mixed>
     */
    public function executeOperation(OperationParams $params, GraphQLContext $context): array
    {
        $errors = $this->graphQLHelper->validateOperationParams($params);

        if ($errors !== []) {
            $errors = array_map(
                static fn (RequestError $err): Error => Error::createLocatedError($err),
                $errors,
            );

            return $this->toSerializableArray(
                new ExecutionResult(null, $errors),
            );
        }

        $queryString = $params->query;

        try {
            if (is_string($queryString)) {
                return $this->executeQueryString(
                    $queryString,
                    $context,
                    $params->variables,
                    null,
                    $params->operation,
                );
            }

            return $this->executeParsedQuery(
                $this->loadPersistedQuery($params->queryId),
                $context,
                $params->variables,
                null,
                $params->operation,
                $params->queryId,
            );
        } catch (\Throwable $throwable) {
            return $this->toSerializableArray(
                new ExecutionResult(null, [Error::createLocatedError($throwable)]),
            );
        }
    }

    /**
     * Parse the given query string into a DocumentNode.
     *
     * Caches the parsed result if the query cache is enabled in the configuration.
     *
     * @api
     */
    public function parse(string $query, string $hash): DocumentNode
    {
        return $this->queryCache->isEnabled()
            ? $this->queryCache->fromCacheOrParse(
                $hash,
                fn (): DocumentNode => $this->parseQuery($query),
            )
            : $this->parseQuery($query);
    }

    /**
     * Convert the result to a serializable array.
     *
     * @api
     *
     * @return SerializableResult
     */
    public function toSerializableArray(ExecutionResult $result): array
    {
        $result->setErrorsHandler($this->errorsHandler());

        return $result->toArray($this->debugFlag());
    }

    /**
     * Loads persisted query from the query cache.
     *
     * @api
     */
    public function loadPersistedQuery(string $sha256hash): DocumentNode
    {
        $lighthouseConfig = $this->configRepository->get('lighthouse');
        if (
            ! $lighthouseConfig['persisted_queries']
            || ! $this->queryCache->isEnabled()
        ) {
            // https://github.com/apollographql/apollo-server/blob/37a5c862261806817a1d71852c4e1d9cdb59eab2/packages/apollo-server-errors/src/index.ts#L240-L248
            throw new Error(message: 'PersistedQueryNotSupported', extensions: ['code' => 'PERSISTED_QUERY_NOT_SUPPORTED']);
        }

        return $this->queryCache->fromCacheOrParse(
            hash: $sha256hash,
            // https://github.com/apollographql/apollo-server/blob/37a5c862261806817a1d71852c4e1d9cdb59eab2/packages/apollo-server-errors/src/index.ts#L230-L239
            parse: fn () => throw new Error(message: 'PersistedQueryNotFound', extensions: ['code' => 'PERSISTED_QUERY_NOT_FOUND']),
        );
    }

    /** @return ErrorsHandler */
    protected function errorsHandler(): callable
    {
        // @phpstan-ignore-next-line callable is not recognized correctly and can not be type-hinted to match
        return $this->errorsHandler ??= function (array $errors, callable $formatter): array {
            // User defined error handlers, implementing \Nuwave\Lighthouse\Execution\ErrorHandler.
            // This allows the user to register multiple handlers and pipe the errors through.
            $handlers = [];
            foreach ($this->configRepository->get('lighthouse.error_handlers', []) as $handlerClass) {
                $handlers[] = Container::getInstance()->make($handlerClass);
            }

            return (new Collection($errors))
                ->map(fn (Error $error): ?array => $this->pipeline
                    ->send($error)
                    ->through($handlers)
                    ->then(static fn (?Error $error): ?array => $error === null
                        ? null
                        : $formatter($error)))
                ->filter()
                ->all();
        };
    }

    protected function debugFlag(): int
    {
        return $this->configRepository->get('app.debug')
            // If Laravel debugging is enabled, we fetch the debug level from the Lighthouse configuration.
            ? (int) $this->configRepository->get('lighthouse.debug')
            // If Laravel debugging is disabled, do not add GraphQL specific debugging info either.
            : DebugFlag::NONE;
    }

    protected function cleanUpAfterExecution(): void
    {
        BatchLoaderRegistry::forgetInstances();
        FieldValue::clear();
        $this->errorPool->clear();
    }

    protected function parseQuery(string $query): DocumentNode
    {
        return Parser::parse($query, [
            'noLocation' => ! $this->configRepository->get('lighthouse.parse_source_location'),
        ]);
    }

    /**
     * Provides a result for cacheable validation rules by running them or retrieving it from the cache.
     *
     * @param  array<string, \GraphQL\Validator\Rules\ValidationRule>  $validationRules
     *
     * @return list<\GraphQL\Error\Error>
     */
    protected function validateCacheableRules(
        array $validationRules,
        Schema $schema,
        string $schemaHash,
        DocumentNode $query,
        ?string $queryHash,
    ): array {
        foreach ($validationRules as $rule) {
            if ($rule instanceof QueryComplexity) {
                throw new \InvalidArgumentException('The QueryComplexity rule must not be registered in cacheableValidationRules, as it depends on variables.');
            }
        }

        if ($queryHash === null) {
            return DocumentValidator::validate($schema, $query, $validationRules); // @phpstan-ignore return.type (TODO remove ignore when requiring a newer version of webonyx/graphql-php)
        }

        $validationCacheConfig = $this->configRepository->get('lighthouse.validation_cache');

        if (! $validationCacheConfig['enable']) {
            return DocumentValidator::validate($schema, $query, $validationRules); // @phpstan-ignore return.type (TODO remove ignore when requiring a newer version of webonyx/graphql-php)
        }

        $cacheFactory = Container::getInstance()->make(CacheFactory::class);
        $store = $cacheFactory->store($validationCacheConfig['store']);

        $cacheKey = "lighthouse:validation:{$schemaHash}:{$queryHash}";

        $cachedResult = $store->get($cacheKey);
        if ($cachedResult !== null) {
            return $cachedResult;
        }

        $result = DocumentValidator::validate($schema, $query, $validationRules);

        // If there are any errors, we return them without caching them.
        // As of webonyx/graphql-php 15.14.0, GraphQL\Error\Error is not serializable.
        // We would have to figure out how to serialize them properly to cache them.
        if ($result !== []) {
            return $result; // @phpstan-ignore return.type (TODO remove ignore when requiring a newer version of webonyx/graphql-php)
        }

        $store->put($cacheKey, $result, $validationCacheConfig['ttl']);

        return $result;
    }
}
