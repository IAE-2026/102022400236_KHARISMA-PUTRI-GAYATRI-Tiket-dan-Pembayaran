<?php declare(strict_types=1);

/**
 * @license Apache 2.0
 */

namespace OpenApi\Attributes;

use OpenApi\Annotations as OA;
use OpenApi\Generator;

#[\Attribute(\Attribute::TARGET_CLASS | \Attribute::TARGET_METHOD)]
class Link extends OA\Link
{
    /**
     * @param string|class-string|object|null $ref
     * @param array<string,mixed>             $parameters
     * @param array<string,mixed>|null        $x
     * @param list<Attachable>|null           $attachables
     */
    public function __construct(
        ?string $link = null,
        ?string $operationRef = null,
        string|object|null $ref = null,
        ?string $operationId = null,
        ?array $parameters = null,
        mixed $requestBody = null,
        ?string $description = Generator::UNDEFINED,
        ?Server $server = null,

        // abstract annotation
        ?array $x = null,
        ?array $attachables = null
    ) {
        parent::__construct([
                'link' => $link ?? Generator::UNDEFINED,
                'operationRef' => $operationRef ?? Generator::UNDEFINED,
                'ref' => $ref ?? Generator::UNDEFINED,
                'operationId' => $operationId ?? Generator::UNDEFINED,
                'parameters' => $parameters ?? Generator::UNDEFINED,
                'requestBody' => $requestBody ?? Generator::UNDEFINED,
                'description' => $description,
                'x' => $x ?? Generator::UNDEFINED,
                'attachables' => $attachables ?? Generator::UNDEFINED,
                'value' => $this->combine($server),
            ]);
    }
}
